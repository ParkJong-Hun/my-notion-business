# Business Administration

[Startup Investment Series](Business%20Administration/Startup%20Investment%20Series%202d8f37315c4480e5aeb9d540a3dcc444.md)

[비상장 주식 거래](Business%20Administration/%EB%B9%84%EC%83%81%EC%9E%A5%20%EC%A3%BC%EC%8B%9D%20%EA%B1%B0%EB%9E%98%202d8f37315c4480959fb9db1867d4a736.md)

[발행주식수](Business%20Administration/%EB%B0%9C%ED%96%89%EC%A3%BC%EC%8B%9D%EC%88%98%202d8f37315c448023a10bc4e14a263b46.md)

[유통 물량](Business%20Administration/%EC%9C%A0%ED%86%B5%20%EB%AC%BC%EB%9F%89%202d8f37315c4480dcb166d7af034bc9d7.md)

[증자](Business%20Administration/%EC%A6%9D%EC%9E%90%202d8f37315c4480bda7b7ec826f6c22ea.md)

[장외 시장](Business%20Administration/%EC%9E%A5%EC%99%B8%20%EC%8B%9C%EC%9E%A5%202d8f37315c44806d8645d044d9b133dc.md)

[주식회사](Business%20Administration/%EC%A3%BC%EC%8B%9D%ED%9A%8C%EC%82%AC%202d8f37315c44808682b1fe6fe7d59a17.md)

[유한회사](Business%20Administration/%EC%9C%A0%ED%95%9C%ED%9A%8C%EC%82%AC%202d8f37315c4480e3b64ecb3bf36017c8.md)

[합명회사](Business%20Administration/%ED%95%A9%EB%AA%85%ED%9A%8C%EC%82%AC%202d8f37315c4480d282a3c62d193119f6.md)

[번 레이트](Business%20Administration/%EB%B2%88%20%EB%A0%88%EC%9D%B4%ED%8A%B8%202d8f37315c4480879474cd8d15831074.md)

[런웨이](Business%20Administration/%EB%9F%B0%EC%9B%A8%EC%9D%B4%202d8f37315c4480c0aec5d92f45e646fb.md)

[기회비용](Business%20Administration/%EA%B8%B0%ED%9A%8C%EB%B9%84%EC%9A%A9%202d8f37315c448032854ace7c95a17f58.md)

[단위 경제](Business%20Administration/%EB%8B%A8%EC%9C%84%20%EA%B2%BD%EC%A0%9C%202d8f37315c44802fbd4eef704d80ace3.md)

[피벗](Business%20Administration/%ED%94%BC%EB%B2%97%202d8f37315c448081b791c335d4c43292.md)

[측정할 수 없으면 관리할 수 없다](Business%20Administration/%EC%B8%A1%EC%A0%95%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%9C%BC%EB%A9%B4%20%EA%B4%80%EB%A6%AC%ED%95%A0%20%EC%88%98%20%EC%97%86%EB%8B%A4%202d8f37315c4480059358e103d8c575d9.md)

[혁신가의 딜레마](Business%20Administration/%ED%98%81%EC%8B%A0%EA%B0%80%EC%9D%98%20%EB%94%9C%EB%A0%88%EB%A7%88%202d8f37315c44808d82a1db506ca54086.md)

[Lean Startup](Business%20Administration/Lean%20Startup%202d8f37315c4480c788afcc3d7961efb5.md)

[FOMO 전략](Business%20Administration/FOMO%20%EC%A0%84%EB%9E%B5%202d8f37315c4480d8a7b0d041c87fce72.md)

[Proxy Metric](Business%20Administration/Proxy%20Metric%202d8f37315c4480e8b537e7c5e0078c91.md)

[해자](Business%20Administration/%ED%95%B4%EC%9E%90%202d8f37315c4480729155c1669e5c8c86.md)

[플라이휠](Business%20Administration/%ED%94%8C%EB%9D%BC%EC%9D%B4%ED%9C%A0%202d8f37315c44807c974bfec02901cecb.md)

[카니발라이제이션](Business%20Administration/%EC%B9%B4%EB%8B%88%EB%B0%9C%EB%9D%BC%EC%9D%B4%EC%A0%9C%EC%9D%B4%EC%85%98%202d8f37315c4480fb9afdc060404a1093.md)

[Core Competency](Business%20Administration/Core%20Competency%202d8f37315c448096912acb90fc682747.md)