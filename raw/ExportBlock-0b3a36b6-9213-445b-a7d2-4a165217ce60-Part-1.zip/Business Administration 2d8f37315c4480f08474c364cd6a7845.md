# Business Administration

[Startup Investment Series](Business%20Administration/Startup%20Investment%20Series%202d8f37315c4480e5aeb9d540a3dcc444.md)

[비상장 주식 거래](Business%20Administration/%EB%B9%84%EC%83%81%EC%9E%A5%20%EC%A3%BC%EC%8B%9D%20%EA%B1%B0%EB%9E%98%202d8f37315c4480959fb9db1867d4a736.md)

[발행주식수](Business%20Administration/%EB%B0%9C%ED%96%89%EC%A3%BC%EC%8B%9D%EC%88%98%202d8f37315c448023a10bc4e14a263b46.md)

[유통 물량](Business%20Administration/%EC%9C%A0%ED%86%B5%20%EB%AC%BC%EB%9F%89%202d8f37315c4480dcb166d7af034bc9d7.md)

[증자](Business%20Administration/%EC%A6%9D%EC%9E%90%202d8f37315c4480bda7b7ec826f6c22ea.md)

[장외 시장](Business%20Administration/%EC%9E%A5%EC%99%B8%20%EC%8B%9C%EC%9E%A5%202d8f37315c44806d8645d044d9b133dc.md)

[주식회사](Business%20Administration/%EC%A3%BC%EC%8B%9D%ED%9A%8C%EC%82%AC%202d8f37315c44808682b1fe6fe7d59a17.md)

[유한회사](Business%20Administration/%EC%9C%A0%ED%95%9C%ED%9A%8C%EC%82%AC%202d8f37315c4480e3b64ecb3bf36017c8.md)

[합명회사](Business%20Administration/%ED%95%A9%EB%AA%85%ED%9A%8C%EC%82%AC%202d8f37315c4480d282a3c62d193119f6.md)

[번 레이트](Business%20Administration/%EB%B2%88%20%EB%A0%88%EC%9D%B4%ED%8A%B8%202d8f37315c4480879474cd8d15831074.md)

[런웨이](Business%20Administration/%EB%9F%B0%EC%9B%A8%EC%9D%B4%202d8f37315c4480c0aec5d92f45e646fb.md)

[기회비용](Business%20Administration/%EA%B8%B0%ED%9A%8C%EB%B9%84%EC%9A%A9%202d8f37315c448032854ace7c95a17f58.md)

[단위 경제](Business%20Administration/%EB%8B%A8%EC%9C%84%20%EA%B2%BD%EC%A0%9C%202d8f37315c44802fbd4eef704d80ace3.md)

[피벗](Business%20Administration/%ED%94%BC%EB%B2%97%202d8f37315c448081b791c335d4c43292.md)

[측정할 수 없으면 관리할 수 없다](Business%20Administration/%EC%B8%A1%EC%A0%95%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%9C%BC%EB%A9%B4%20%EA%B4%80%EB%A6%AC%ED%95%A0%20%EC%88%98%20%EC%97%86%EB%8B%A4%202d8f37315c4480059358e103d8c575d9.md)

[혁신가의 딜레마](Business%20Administration/%ED%98%81%EC%8B%A0%EA%B0%80%EC%9D%98%20%EB%94%9C%EB%A0%88%EB%A7%88%202d8f37315c44808d82a1db506ca54086.md)

[Lean Startup](Business%20Administration/Lean%20Startup%202d8f37315c4480c788afcc3d7961efb5.md)

[FOMO 전략](Business%20Administration/FOMO%20%EC%A0%84%EB%9E%B5%202d8f37315c4480d8a7b0d041c87fce72.md)

[Proxy Metric](Business%20Administration/Proxy%20Metric%202d8f37315c4480e8b537e7c5e0078c91.md)

[해자](Business%20Administration/%ED%95%B4%EC%9E%90%202d8f37315c4480729155c1669e5c8c86.md)

[플라이휠](Business%20Administration/%ED%94%8C%EB%9D%BC%EC%9D%B4%ED%9C%A0%202d8f37315c44807c974bfec02901cecb.md)

[카니발라이제이션](Business%20Administration/%EC%B9%B4%EB%8B%88%EB%B0%9C%EB%9D%BC%EC%9D%B4%EC%A0%9C%EC%9D%B4%EC%85%98%202d8f37315c4480fb9afdc060404a1093.md)

[Core Competency](Business%20Administration/Core%20Competency%202d8f37315c448096912acb90fc682747.md)

[일본 법](Business%20Administration/%EC%9D%BC%EB%B3%B8%20%EB%B2%95%202e3f37315c4480999877ea3d156311db.md)

[마케팅](Business%20Administration/%EB%A7%88%EC%BC%80%ED%8C%85%202e3f37315c4480ff910bcb2a1d330968.md)

[현지화](Business%20Administration/%ED%98%84%EC%A7%80%ED%99%94%202e3f37315c44809180afc9438a553e36.md)

[PMF](Business%20Administration/PMF%202e5f37315c44802b9d48d4d97b8b4ccd.md)

[LTV](Business%20Administration/LTV%202e5f37315c44807bbc40c3747fe3038a.md)

[Churn Rate](Business%20Administration/Churn%20Rate%202e5f37315c4480f58bf7fb4c7f15c934.md)

[Burn Rate](Business%20Administration/Burn%20Rate%202e5f37315c4480e8a28aef9229011882.md)

[Cap Table](Business%20Administration/Cap%20Table%202e5f37315c4480178e94ead6fe4a6f96.md)

[Vesting](Business%20Administration/Vesting%202e5f37315c4480b785fff9b4d7ade09a.md)

[MRR](Business%20Administration/MRR%202e5f37315c44800db2fcf6c4011fc702.md)

[ARR](Business%20Administration/ARR%202e5f37315c44801fa15cd14702f4bcb7.md)

[ARPU](Business%20Administration/ARPU%202e5f37315c448048a4f6ff82f0cbab24.md)

[Retention Rate](Business%20Administration/Retention%20Rate%202e5f37315c4480e28c86eca14638338a.md)

[NRR](Business%20Administration/NRR%202e5f37315c4480859c6bd247fc1c1d11.md)

[CAC Payback Period](Business%20Administration/CAC%20Payback%20Period%202e5f37315c44800a800fc4a098cea135.md)

[Burn Multiple](Business%20Administration/Burn%20Multiple%202e5f37315c4480619593e7c57cc7d9da.md)

[AARRR Model](Business%20Administration/AARRR%20Model%202e5f37315c44801dad0fc1e66b005230.md)

[Problem-Solution Fit](Business%20Administration/Problem-Solution%20Fit%202e5f37315c448012b29fd0b5cd48e871.md)

[Soft Launch](Business%20Administration/Soft%20Launch%202e5f37315c44802493e8e20028fa56ba.md)

[Aha-Moment](Business%20Administration/Aha-Moment%202e5f37315c4480f29ec9d61428082233.md)

[ROI based Decision](Business%20Administration/ROI%20based%20Decision%202e5f37315c44807f9cdbc0fb647c2376.md)

[Opportunity Cost](Business%20Administration/Opportunity%20Cost%202e5f37315c4480ceac57c72009f37e22.md)

[Functional Organization](Business%20Administration/Functional%20Organization%202e5f37315c448040889acdfb4aafa012.md)

[Squad/Cross-functional Team](Business%20Administration/Squad%20Cross-functional%20Team%202e5f37315c4480edac0cc8d789f16b73.md)

[OKR](Business%20Administration/OKR%202e5f37315c448089b0f1d1ec1e2937d2.md)

[CMMI](Business%20Administration/CMMI%202e5f37315c44805ea670c8eee5dedbae.md)

[스타트업 개발자 역할](Business%20Administration/%EC%8A%A4%ED%83%80%ED%8A%B8%EC%97%85%20%EA%B0%9C%EB%B0%9C%EC%9E%90%20%EC%97%AD%ED%95%A0%202e5f37315c4480668b2fc0a6b56945bb.md)

[채용의 버스 이론](Business%20Administration/%EC%B1%84%EC%9A%A9%EC%9D%98%20%EB%B2%84%EC%8A%A4%20%EC%9D%B4%EB%A1%A0%202e5f37315c448004b12ccbad72600e8a.md)

[Apple 정책](Business%20Administration/Apple%20%EC%A0%95%EC%B1%85%202eff37315c44802abc9fc8943edf0726.md)

[Google 정책](Business%20Administration/Google%20%EC%A0%95%EC%B1%85%202eff37315c4480c5bee1cf6e0109b241.md)

[AI 콘텐츠 표기](Business%20Administration/AI%20%EC%BD%98%ED%85%90%EC%B8%A0%20%ED%91%9C%EA%B8%B0%202eff37315c448012986dfabc23009860.md)

[대한민국 법률](Business%20Administration/%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD%20%EB%B2%95%EB%A5%A0%202eff37315c44800cae07c714b854004c.md)

[유럽 법률](Business%20Administration/%EC%9C%A0%EB%9F%BD%20%EB%B2%95%EB%A5%A0%202eff37315c448036a53dcea8628859d3.md)

[미국 법률](Business%20Administration/%EB%AF%B8%EA%B5%AD%20%EB%B2%95%EB%A5%A0%202eff37315c44808d99bcc74c1499bc2e.md)

[일반적 정책](Business%20Administration/%EC%9D%BC%EB%B0%98%EC%A0%81%20%EC%A0%95%EC%B1%85%202eff37315c4480b8acbad24521e86cac.md)

[TermsFeed](Business%20Administration/TermsFeed%202eff37315c4480e5ad9be3a90e7044d8.md)