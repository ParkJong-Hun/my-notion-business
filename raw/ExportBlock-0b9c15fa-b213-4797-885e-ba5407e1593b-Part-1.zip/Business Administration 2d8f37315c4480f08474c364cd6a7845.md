# Business Administration

[Startup Investment Series](Business%20Administration/Startup%20Investment%20Series%202d8f37315c4480e5aeb9d540a3dcc444.md)

[비상장 주식 거래](Business%20Administration/%EB%B9%84%EC%83%81%EC%9E%A5%20%EC%A3%BC%EC%8B%9D%20%EA%B1%B0%EB%9E%98%202d8f37315c4480959fb9db1867d4a736.md)

[발행주식수](Business%20Administration/%EB%B0%9C%ED%96%89%EC%A3%BC%EC%8B%9D%EC%88%98%202d8f37315c448023a10bc4e14a263b46.md)

[유통 물량](Business%20Administration/%EC%9C%A0%ED%86%B5%20%EB%AC%BC%EB%9F%89%202d8f37315c4480dcb166d7af034bc9d7.md)

[증자](Business%20Administration/%EC%A6%9D%EC%9E%90%202d8f37315c4480bda7b7ec826f6c22ea.md)

[장외 시장](Business%20Administration/%EC%9E%A5%EC%99%B8%20%EC%8B%9C%EC%9E%A5%202d8f37315c44806d8645d044d9b133dc.md)

[주식회사](Business%20Administration/%EC%A3%BC%EC%8B%9D%ED%9A%8C%EC%82%AC%202d8f37315c44808682b1fe6fe7d59a17.md)

[유한회사](Business%20Administration/%EC%9C%A0%ED%95%9C%ED%9A%8C%EC%82%AC%202d8f37315c4480e3b64ecb3bf36017c8.md)

[합명회사](Business%20Administration/%ED%95%A9%EB%AA%85%ED%9A%8C%EC%82%AC%202d8f37315c4480d282a3c62d193119f6.md)

[번 레이트](Business%20Administration/%EB%B2%88%20%EB%A0%88%EC%9D%B4%ED%8A%B8%202d8f37315c4480879474cd8d15831074.md)

[런웨이](Business%20Administration/%EB%9F%B0%EC%9B%A8%EC%9D%B4%202d8f37315c4480c0aec5d92f45e646fb.md)

[기회비용](Business%20Administration/%EA%B8%B0%ED%9A%8C%EB%B9%84%EC%9A%A9%202d8f37315c448032854ace7c95a17f58.md)

[단위 경제](Business%20Administration/%EB%8B%A8%EC%9C%84%20%EA%B2%BD%EC%A0%9C%202d8f37315c44802fbd4eef704d80ace3.md)

[피벗](Business%20Administration/%ED%94%BC%EB%B2%97%202d8f37315c448081b791c335d4c43292.md)

[측정할 수 없으면 관리할 수 없다](Business%20Administration/%EC%B8%A1%EC%A0%95%ED%95%A0%20%EC%88%98%20%EC%97%86%EC%9C%BC%EB%A9%B4%20%EA%B4%80%EB%A6%AC%ED%95%A0%20%EC%88%98%20%EC%97%86%EB%8B%A4%202d8f37315c4480059358e103d8c575d9.md)

[혁신가의 딜레마](Business%20Administration/%ED%98%81%EC%8B%A0%EA%B0%80%EC%9D%98%20%EB%94%9C%EB%A0%88%EB%A7%88%202d8f37315c44808d82a1db506ca54086.md)

[Lean Startup](Business%20Administration/Lean%20Startup%202d8f37315c4480c788afcc3d7961efb5.md)

[FOMO 전략](Business%20Administration/FOMO%20%EC%A0%84%EB%9E%B5%202d8f37315c4480d8a7b0d041c87fce72.md)

[Proxy Metric](Business%20Administration/Proxy%20Metric%202d8f37315c4480e8b537e7c5e0078c91.md)

[해자](Business%20Administration/%ED%95%B4%EC%9E%90%202d8f37315c4480729155c1669e5c8c86.md)

[플라이휠](Business%20Administration/%ED%94%8C%EB%9D%BC%EC%9D%B4%ED%9C%A0%202d8f37315c44807c974bfec02901cecb.md)

[카니발라이제이션](Business%20Administration/%EC%B9%B4%EB%8B%88%EB%B0%9C%EB%9D%BC%EC%9D%B4%EC%A0%9C%EC%9D%B4%EC%85%98%202d8f37315c4480fb9afdc060404a1093.md)

[Core Competency](Business%20Administration/Core%20Competency%202d8f37315c448096912acb90fc682747.md)

[일본 법](Business%20Administration/%EC%9D%BC%EB%B3%B8%20%EB%B2%95%202e3f37315c4480999877ea3d156311db.md)

[마케팅](Business%20Administration/%EB%A7%88%EC%BC%80%ED%8C%85%202e3f37315c4480ff910bcb2a1d330968.md)

[현지화](Business%20Administration/%ED%98%84%EC%A7%80%ED%99%94%202e3f37315c44809180afc9438a553e36.md)

[PMF](Business%20Administration/PMF%202e5f37315c44802b9d48d4d97b8b4ccd.md)

[LTV](Business%20Administration/LTV%202e5f37315c44807bbc40c3747fe3038a.md)

[Churn Rate](Business%20Administration/Churn%20Rate%202e5f37315c4480f58bf7fb4c7f15c934.md)

[Burn Rate](Business%20Administration/Burn%20Rate%202e5f37315c4480e8a28aef9229011882.md)

[Cap Table](Business%20Administration/Cap%20Table%202e5f37315c4480178e94ead6fe4a6f96.md)

[Vesting](Business%20Administration/Vesting%202e5f37315c4480b785fff9b4d7ade09a.md)

[MRR](Business%20Administration/MRR%202e5f37315c44800db2fcf6c4011fc702.md)

[ARR](Business%20Administration/ARR%202e5f37315c44801fa15cd14702f4bcb7.md)

[ARPU](Business%20Administration/ARPU%202e5f37315c448048a4f6ff82f0cbab24.md)

[Retention Rate](Business%20Administration/Retention%20Rate%202e5f37315c4480e28c86eca14638338a.md)

[NRR](Business%20Administration/NRR%202e5f37315c4480859c6bd247fc1c1d11.md)

[CAC Payback Period](Business%20Administration/CAC%20Payback%20Period%202e5f37315c44800a800fc4a098cea135.md)

[Burn Multiple](Business%20Administration/Burn%20Multiple%202e5f37315c4480619593e7c57cc7d9da.md)

[AARRR Model](Business%20Administration/AARRR%20Model%202e5f37315c44801dad0fc1e66b005230.md)

[Problem-Solution Fit](Business%20Administration/Problem-Solution%20Fit%202e5f37315c448012b29fd0b5cd48e871.md)

[Soft Launch](Business%20Administration/Soft%20Launch%202e5f37315c44802493e8e20028fa56ba.md)

[Aha-Moment](Business%20Administration/Aha-Moment%202e5f37315c4480f29ec9d61428082233.md)

[ROI based Decision](Business%20Administration/ROI%20based%20Decision%202e5f37315c44807f9cdbc0fb647c2376.md)

[Opportunity Cost](Business%20Administration/Opportunity%20Cost%202e5f37315c4480ceac57c72009f37e22.md)

[Functional Organization](Business%20Administration/Functional%20Organization%202e5f37315c448040889acdfb4aafa012.md)

[Squad/Cross-functional Team](Business%20Administration/Squad%20Cross-functional%20Team%202e5f37315c4480edac0cc8d789f16b73.md)

[OKR](Business%20Administration/OKR%202e5f37315c448089b0f1d1ec1e2937d2.md)

[CMMI](Business%20Administration/CMMI%202e5f37315c44805ea670c8eee5dedbae.md)

[스타트업 개발자 역할](Business%20Administration/%EC%8A%A4%ED%83%80%ED%8A%B8%EC%97%85%20%EA%B0%9C%EB%B0%9C%EC%9E%90%20%EC%97%AD%ED%95%A0%202e5f37315c4480668b2fc0a6b56945bb.md)

[채용의 버스 이론](Business%20Administration/%EC%B1%84%EC%9A%A9%EC%9D%98%20%EB%B2%84%EC%8A%A4%20%EC%9D%B4%EB%A1%A0%202e5f37315c448004b12ccbad72600e8a.md)

[Apple 정책](Business%20Administration/Apple%20%EC%A0%95%EC%B1%85%202eff37315c44802abc9fc8943edf0726.md)

[Google 정책](Business%20Administration/Google%20%EC%A0%95%EC%B1%85%202eff37315c4480c5bee1cf6e0109b241.md)

[AI 콘텐츠 표기](Business%20Administration/AI%20%EC%BD%98%ED%85%90%EC%B8%A0%20%ED%91%9C%EA%B8%B0%202eff37315c448012986dfabc23009860.md)

[대한민국 법률](Business%20Administration/%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD%20%EB%B2%95%EB%A5%A0%202eff37315c44800cae07c714b854004c.md)

[유럽 법률](Business%20Administration/%EC%9C%A0%EB%9F%BD%20%EB%B2%95%EB%A5%A0%202eff37315c448036a53dcea8628859d3.md)

[미국 법률](Business%20Administration/%EB%AF%B8%EA%B5%AD%20%EB%B2%95%EB%A5%A0%202eff37315c44808d99bcc74c1499bc2e.md)

[일반적 정책](Business%20Administration/%EC%9D%BC%EB%B0%98%EC%A0%81%20%EC%A0%95%EC%B1%85%202eff37315c4480b8acbad24521e86cac.md)

[TermsFeed](Business%20Administration/TermsFeed%202eff37315c4480e5ad9be3a90e7044d8.md)

[Five Whys](Business%20Administration/Five%20Whys%2034af37315c44806ea7d1c00597bea456.md)

[MECE](Business%20Administration/MECE%2034af37315c4480d88141c4420454f060.md)

[Covey](Business%20Administration/Covey%2034af37315c448088b4c4ffe30daec997.md)

[Inversion](Business%20Administration/Inversion%2034af37315c44805a9932dad13a26f408.md)

[First Principles Thinking](Business%20Administration/First%20Principles%20Thinking%2034af37315c448005b1f1ed55f99f3145.md)

[Problem Framing](Business%20Administration/Problem%20Framing%2034af37315c4480cf8e72db8c1bf41af6.md)

[Theory of Constraints](Business%20Administration/Theory%20of%20Constraints%2034af37315c448030bc53ccd2cad12e37.md)

[Second-Order Thinking](Business%20Administration/Second-Order%20Thinking%2034af37315c4480afa534c79cc67e586c.md)

[Opportunity Cost](Business%20Administration/Opportunity%20Cost%2034af37315c4480e5960dd7a0a1fc3fb5.md)

[OODA Loop](Business%20Administration/OODA%20Loop%2034af37315c4480228e4ce2dd13e3478c.md)

[Reversible vs Irreversible Decisions](Business%20Administration/Reversible%20vs%20Irreversible%20Decisions%2034af37315c448053b135e9255c37c7ae.md)

[Pareto Principle](Business%20Administration/Pareto%20Principle%2034af37315c4480eda633ef49500fb832.md)

[Chesterton’s Fence](Business%20Administration/Chesterton%E2%80%99s%20Fence%2034af37315c4480fd8c8dd8c18cb618b0.md)

[Conway’s Law](Business%20Administration/Conway%E2%80%99s%20Law%2034af37315c4480febf10c04640cc1bae.md)

[Satisficing](Business%20Administration/Satisficing%2034af37315c4480c1b0b2c4bc403db814.md)

[Dunning-Kruger Effect](Business%20Administration/Dunning-Kruger%20Effect%2034af37315c4480d7ae6ad62a347f3618.md)

[Map is not the Territory](Business%20Administration/Map%20is%20not%20the%20Territory%2034af37315c4480d9a6dff3f4f673c0a9.md)

[Cynefin Framework](Business%20Administration/Cynefin%20Framework%2034af37315c448036932ee26dc482eaf6.md)

[Wardley Mapping](Business%20Administration/Wardley%20Mapping%2034af37315c44804b8446f6248f2cd051.md)

[Requisite Variety](Business%20Administration/Requisite%20Variety%2034af37315c448026b590fb317d61a451.md)

[Double-loop-learning](Business%20Administration/Double-loop-learning%2034af37315c4480a4b19bc0d1a1e16127.md)

[Goodhart’s Law](Business%20Administration/Goodhart%E2%80%99s%20Law%2034af37315c4480b2aeced46f938d06ca.md)

[Term Sheet](Business%20Administration/Term%20Sheet%2034af37315c4480d6b6f2c449f8f174d7.md)

[Pre-money/Post-money Valuation](Business%20Administration/Pre-money%20Post-money%20Valuation%2034af37315c4480bc9c00c1860c6324a4.md)

[Liquidation Preference](Business%20Administration/Liquidation%20Preference%2034af37315c4480f89bcffdf6f8336e97.md)

[Anti-dilution](Business%20Administration/Anti-dilution%2034af37315c4480229ca9ccbf5bab725c.md)

[SAFE / Convertible Note](Business%20Administration/SAFE%20Convertible%20Note%2034af37315c44809b980bcc80ff301d85.md)

[Pro-rata Rights](Business%20Administration/Pro-rata%20Rights%2034af37315c448021bae3ca0d3a0d410d.md)

[Down Round](Business%20Administration/Down%20Round%2034af37315c44805b84d3ded02ecfc58e.md)

[SHA](Business%20Administration/SHA%2034af37315c4480c7ad47cc343be0afe1.md)

[IP 양도 계약](Business%20Administration/IP%20%EC%96%91%EB%8F%84%20%EA%B3%84%EC%95%BD%2034af37315c44809da462f32739943a69.md)

[NDA](Business%20Administration/NDA%2034af37315c448033b844cd689add3246.md)

[P&L](Business%20Administration/P&L%2034af37315c448014b4e1d5469f7dcb9f.md)

[현금흐름표](Business%20Administration/%ED%98%84%EA%B8%88%ED%9D%90%EB%A6%84%ED%91%9C%2034af37315c4480ebb1a7f06c9f59b48a.md)

[Gross Margin](Business%20Administration/Gross%20Margin%2034af37315c448058a6fef3ba1b68c60c.md)

[Working Capital](Business%20Administration/Working%20Capital%2034af37315c44805a8254c2558efc4bc3.md)

[GTM Strategy](Business%20Administration/GTM%20Strategy%2034af37315c4480d0aa8bf8334671bc25.md)

[ICP](Business%20Administration/ICP%2034af37315c44803799a7fae2dcdb0375.md)

[PLG](Business%20Administration/PLG%2034af37315c4480eda7c9e2ec86e138dd.md)

[SLG](Business%20Administration/SLG%2034af37315c44800586acc8b8cd602a16.md)

[Champion](Business%20Administration/Champion%2034af37315c4480ee9849dbcee49f5a64.md)

[JTBD](Business%20Administration/JTBD%2034af37315c4480e08d99d08f29908e89.md)

[Kano Model](Business%20Administration/Kano%20Model%2034af37315c4480948248f486c2e93a6d.md)

[North Star Metric](Business%20Administration/North%20Star%20Metric%2034af37315c4480f9ab5ff568d3dbbe22.md)

[Feature Factory의 함정](Business%20Administration/Feature%20Factory%EC%9D%98%20%ED%95%A8%EC%A0%95%2034af37315c4480af9b80cdd3051d6f34.md)

[Discovery vs Delivery](Business%20Administration/Discovery%20vs%20Delivery%2034af37315c448058ade0e92d5008e1e5.md)

[Survivorship Bias](Business%20Administration/Survivorship%20Bias%2034af37315c4480f799aee7f49fbb6110.md)

[Sunk Cost Fallacy](Business%20Administration/Sunk%20Cost%20Fallacy%2034af37315c448022b1a9c3848a077e04.md)

[Confirmation Bias](Business%20Administration/Confirmation%20Bias%2034af37315c4480039dfcd88ca8494d0d.md)

[Planning Fallacy](Business%20Administration/Planning%20Fallacy%2034af37315c44801f8e94c6c68ade3351.md)

[Founder-Market Fix](Business%20Administration/Founder-Market%20Fix%2034af37315c448045922df273cd267f24.md)

[일본 엔터프라이즈 영업 사이클](Business%20Administration/%EC%9D%BC%EB%B3%B8%20%EC%97%94%ED%84%B0%ED%94%84%EB%9D%BC%EC%9D%B4%EC%A6%88%20%EC%98%81%EC%97%85%20%EC%82%AC%EC%9D%B4%ED%81%B4%2034af37315c4480f888c9d25806c5c951.md)

[ringi 문화](Business%20Administration/ringi%20%EB%AC%B8%ED%99%94%2034af37315c4480a8b536fa1bc94835fc.md)

[도입사례의 중요성](Business%20Administration/%EB%8F%84%EC%9E%85%EC%82%AC%EB%A1%80%EC%9D%98%20%EC%A4%91%EC%9A%94%EC%84%B1%2034af37315c4480cfb961fa36e0a20b23.md)

[J-KISS](Business%20Administration/J-KISS%2034af37315c4480b3bd76d58fb4c1c666.md)

[Deep Work vs Shallow Work](Business%20Administration/Deep%20Work%20vs%20Shallow%20Work%2034af37315c44800ea8a8ce89f78c022f.md)

[Build vs Buy vs Borrow](Business%20Administration/Build%20vs%20Buy%20vs%20Borrow%2034af37315c448063b3a3c35e769009b1.md)

[Boring Technology 원칙](Business%20Administration/Boring%20Technology%20%EC%9B%90%EC%B9%99%2034af37315c448073ba5de06a17b6fe46.md)

[수익화 / 가격 책정](Business%20Administration/%EC%88%98%EC%9D%B5%ED%99%94%20%EA%B0%80%EA%B2%A9%20%EC%B1%85%EC%A0%95%2034af37315c4480e2baccfee8e7d8f8f7.md)

[Build in Public](Business%20Administration/Build%20in%20Public%2034af37315c4480dbb027fe7d82042137.md)

[Product Hunt](Business%20Administration/Product%20Hunt%2034af37315c448095b80bce44c3f993a7.md)

[커뮤니티 마케팅](Business%20Administration/%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%20%EB%A7%88%EC%BC%80%ED%8C%85%2034af37315c44800a989ed39af434b66f.md)

[Ramen Profitability](Business%20Administration/Ramen%20Profitability%2034af37315c4480aea43de02990ca7adc.md)

[Comparison Trap](Business%20Administration/Comparison%20Trap%2034af37315c4480a9844df7931e473749.md)